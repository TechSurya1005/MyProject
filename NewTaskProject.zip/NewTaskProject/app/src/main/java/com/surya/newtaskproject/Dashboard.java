package com.surya.newtaskproject;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class Dashboard extends Fragment {

    Spinner spnFilter;

    public Dashboard() {
        // Required empty public constructor
    }
        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

            View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
            spnFilter = (Spinner) view.findViewById(R.id.spnFilter);

            ArrayList<String> arrayList = new ArrayList<>();
            arrayList.add("Weekly");
            arrayList.add("Monthly");
            arrayList.add("Yearly");
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getContext(), androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,arrayList);
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spnFilter.setAdapter(arrayAdapter);

            return view;

    }
}